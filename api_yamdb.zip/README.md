# YamDB — платформа для отзывов на произведения


[![Python](https://img.shields.io/badge/Python-3.9-blue)](https://python.org)
[![Django](https://img.shields.io/badge/Django-3.2-green)](https://djangoproject.com)
[![DRF](https://img.shields.io/badge/DRF-3.12-red)](https://www.django-rest-framework.org)


**YamDB** — это платформа, где пользователи могут публиковать отзывы и оценки на произведения разных категорий: фильмы, книги, музыку и другие медиа. Проект включает:

- RESTful API (бекенд)
- Веб-интерфейс (фронтенд)
- Аутентификацию через JWT-токены

## Возможности

### Для пользователей

- 📝 Публикация отзывов и оценок (1-10 баллов)
- 💬 Комментирование отзывов других пользователей
- 🔍 Поиск произведений по жанрам и  категориям

### Для администраторов

- 🛠 Управление пользователями и контентом
- 🏷 Добавление новых категорий и жанров
- 📊 Модерация контента

## Технологии

### Бекенд

- Python 3.10

- Django 3.2

- Django REST Framework 3.12

- JWT-аутентификация


### Фронтенд

- JavaScript
- HTML
- CSS
- Bootstrap


## Установка

1. Клонирование проекта

Клонируйте репозиторий на ваш компьютер:

#### Windows/macOS/Linux:
```bash
git clone git@github.com:HermannRorshach/api_yamdb.git
```

### 2. Установка виртуального окружения с Python 3.10

#### Windows:
```bash
py -3.10 -m venv venv
```
#### macOS/Linux:
```bash
`python3.10 -m venv venv`
```

### 3. Активировать виртуальное окружение

#### Windows:

```python
source venv/Scripts/activate
```
#### macOS/Linux:
```bash
source venv/bin/activate
```

### 4. Установка зависимостей

После активации виртуального окружения установите все необходимые зависимости с помощью pip:
#### Windows/macOS/Linux:
```bash
pip install -r requirements.txt
```

## API Endpoints

|Метод|Эндпоинт|Описание|
|---|---|---|
|GET|`/api/v1/titles/`|Список произведений|
|POST|`/api/v1/titles/{id}/reviews/`|Добавить отзыв|
|GET|`/api/v1/users/me/`|Профиль текущего пользователя|

Полная документация API доступна после запуска проекта по адресу:
`http://localhost:8000/redoc/`

**Автор**: Борисов Павел, веб-разработчик
**Год**: 2025